# Conecta-4
# Ejecutar en este orden:


1.  go run .\connect4.go  
2.  python .\middleware.py     
3.  python .\player.py     


Aparecera el menú 2 opciones:

opción 1 Jugar
opción 2 Salir


Al apretar Jugar dará inicio a la partida y saldrá 3 opciones más

opción 1 Ver Tablero
opción 2 Realizar Movimiento
opción 3 Salir 



